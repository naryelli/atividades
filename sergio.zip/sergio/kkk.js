// Array de produtos
const produtos = ['Caneta', 'Lápis', 'Borracha', 'Régua', 'Caderno', 'Lapiseira'];

// Array de preços
const precos = [5.25, 2.99, 3.99, 5.50, 15.90, 22.59];

// Array de quantidades em estoque
const qtdEstoque = [27, 53, 60, 33, 28, 15];

// Função para buscar o índice de um produto
function buscarIndiceProduto(nomeProduto) {
  const indice = produtos.indexOf(nomeProduto);
  if (indice === -1) {
    throw new Error(`Produto "${nomeProduto}" não encontrado.`);
  }
  return indice;
}

// Função para realizar uma compra
function comprar(nomeProduto, quantidade) {
  const indice = buscarIndiceProduto(nomeProduto);
  if (quantidade <= qtdEstoque[indice]) {
    qtdEstoque[indice] += quantidade;
    console.log(`Compra de ${quantidade} ${nomeProduto} realizada com sucesso! Estoque atualizado: ${qtdEstoque[indice]}.`);
  } else {
    throw new Error(`Quantidade excede o estoque disponível para ${nomeProduto}.`);
  }
}

// Função para realizar uma venda
function vender(nomeProduto, quantidade) {
  const indice = buscarIndiceProduto(nomeProduto);
  if (quantidade <= qtdEstoque[indice]) {
    qtdEstoque[indice] -= quantidade;
    console.log(`Venda de ${quantidade} ${nomeProduto} realizada com sucesso! Estoque atualizado: ${qtdEstoque[indice]}.`);
  } else {
    throw new Error(`Quantidade excede o estoque disponível para ${nomeProduto}.`);
  }
}

// Função para cadastrar um novo produto
function cadastrarProduto(nomeProduto, preco, quantidade) {
  if (produtos.includes(nomeProduto)) {
    throw new Error(`Produto "${nomeProduto}" já existe no cadastro.`);
  }

  produtos.push(nomeProduto);
  precos.push(preco);
  qtdEstoque.push(quantidade);

  console.log(`Produto "${nomeProduto}" cadastrado com sucesso!`);
}

// Exemplo de uso das funções
comprar('Caneta', 10);
vender('Borracha', 5);
cadastrarProduto('Mochila', 35.90, 12);
