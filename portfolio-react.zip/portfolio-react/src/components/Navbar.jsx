import React from 'react';


export default function Navbar(){
    return(
        <nav className="navbar">
          <li><a href="../App.jsx">Início</a></li>
          <li><a href="">Linguagens</a></li>
          <li><a href="">Matematica</a></li>
          <li><a href="">Ciências humanas</a></li>
          <li><a href="">Ciências da natureza</a></li>
          <li><a href="">Desenvolvimento de sistemas</a></li>
        </nav>
    )
}