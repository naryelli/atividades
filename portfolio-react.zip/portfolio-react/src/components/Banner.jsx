import React from 'react';
import TextBig from './TextBig';
import Button from './Button';


export default function Banner(){
    return(
        <div className='banner container'>
            <div className="two-column content">
                <div className="inner-content">
                    <TextBig label="Portfolio"/>
                    <p>Naryelli Julia de Souza.</p>
                    
                </div>
            </div>
            <div className="two-column content">
                <img src="../public/nary.JPG" alt="" />
            </div>
        </div>
    )
}