import React from 'react';
import ItemImg from './ItemImg';
import TextBig from './TextBig';


export default function Galery(){
    return(
        <div className="one-column content">
           
            <div className="inner-container">
                
                </div>
        </div>
    )
}